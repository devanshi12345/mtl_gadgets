<center><!--  center Begin  -->
    
    <h1> Pay offline using Metthod </h1>
    
   
    
    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service work <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->